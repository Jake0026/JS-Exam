function randomInteger(min, max) {
    // случайное число от min до (max+1)
    let rand = min + Math.random() * (max + 1 - min);
    return Math.floor(rand);
}

let play = document.getElementById("play");
let form = document.querySelector(".form");
let points = document.querySelector(".points");
let rates = document.getElementsByName('bet');
let value;
let count = 0;
let message = document.querySelector(".message");
let end = document.querySelector(".container");
function Play() {
}
for (var i = 0; i < rates.length; i++) {
    rates[i].addEventListener('change', function() {
        value = this.value
    });
}
function Play() {
    play.addEventListener("click", function(event) {
        if (count < 10) {
    
        let number = randomInteger(0, 36);
        form.textContent = number;
        points.textContent = count;
    
        if ((number % 2 == 0 && value == "red") || ((number % 2 == 0 && value == "even"))) {
            message.textContent = "You won!";
            count++;
        }
        else if ((number % 2 != 0 && value == "black") || ((number % 2 != 0 && value == "odd"))) {
            message.textContent = "You won!";
            count++;
        }
        else {
            message.textContent = "You lost!";
        }
    }
    if (count > 9) {
        points.textContent = 10;
        end.style.display = "block";
        end.textContent = "Congratulation, you won 10 times!";
    }
    });
}
Play();